#pragma once
ref class CreditAccount
{
public:
	 literal String ^name = "Super Platinum Card";
};