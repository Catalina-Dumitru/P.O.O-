#pragma once

using namespace System;

ref class CreditCardAccount
{
public:
	literal String^ name = "Super Platinum Card";
public:
	void SetCreditLimit(double amount);
	bool MakePurchase(double amount);
	void MakeRepayment(double amount);
	void PrintStatement();
	long GetAccountNumber();

private:
	initonly long accountNumber;
	double currentBalance;
	double creditLimit;
	
public:   
	CreditCardAccount();   

public:  
	CreditCardAccount(long number, double limit);  
	// ... Other members, as before };

private:
	static int numberOfAccounts = 0;
	// ... Other members, as before

public:    
	static int GetNumberOfAccounts();
	// ... Other members, as before 

private:
	static double interestRate;

public:
	static CreditCardAccount();

};

