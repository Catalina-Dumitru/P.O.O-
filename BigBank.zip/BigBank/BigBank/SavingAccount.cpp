#include "pch.h"
#include "SavingAccount.h"

SavingAccount::SavingAccount(String ^holder) : BankAccount(holder) { }
void SavingAccount::SetInterestRate(double rate)
{
	interestRate = rate;
}
double SavingAccount::GetInterestRate()
{
	return interestRate;
}
