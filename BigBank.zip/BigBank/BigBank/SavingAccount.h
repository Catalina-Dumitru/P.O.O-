#pragma once

#include "BankAccount.h"

ref class SavingAccount : BankAccount
{
public:
	SavingAccount(String^ holder);
	static void SetInterestRate(double rate);
	static double GetInterestRate();
private:
	static double interestRate;
};