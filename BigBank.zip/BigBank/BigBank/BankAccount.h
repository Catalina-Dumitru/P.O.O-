#pragma once
using namespace System;
ref class BankAccount abstract 
{
public:
	BankAccount(String^ holder);
	void Credit(double amount);
	void Debit(double amount);
	double GetBalance();
	virtual String^ ToString() override;
	virtual bool CanDebit(double amount) abstract;
private:
	String^ accountHolder;
	double balance;
};