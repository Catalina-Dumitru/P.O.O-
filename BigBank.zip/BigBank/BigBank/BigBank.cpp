#include "pch.h"
#include "CurrentAccount.h"
#include "SavingAccount.h"
using namespace System;

int main(array<System::String ^> ^args)
{
    CurrentAccount acc("Me", 200.0);
    acc.Credit(100.0);

    double balance = acc.GetBalance();
    double overdraft = acc.GetOverdraftLimit();

    Console::WriteLine("Balance:{0}", balance);
    Console::WriteLine("Overdraft:{0}", overdraft);

    SavingAccount::SetInterestRate(2.5);
    SavingAccount sacc("You");
    double rate = sacc.GetInterestRate();

    Console::WriteLine("Interest rate:{0}", rate);

}
